namespace IMS
{
    public interface IReportable
    {
        string GenerateReport();
    }
}
